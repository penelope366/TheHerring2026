<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Herring</title>
    <meta name="description" content="The Herring is the independent student-run newspaper of Amsterdam University College" />
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <link href="wp-content/themes/Herring/style.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <style>
    
      
      .brand-title {
        font-family: 'Times New Roman', Times, serif;
        font-weight: bold;
        letter-spacing: 2px;
      }
      
      .border-top-thick {
        border-top: 3px solid #000 !important;
      }
      .border-bottom-thick {
        border-bottom: 3px solid #000 !important;
      }
  
      /* Vertical divider between main feature and sidebar on Desktop */
      @media (min-width: 768px) {
        .border-end-md {
          border-right: 1px solid #ccc !important;
        }
      }
    </style>
    <?php wp_head(); ?>
    </head>
    <body>
    <!-- The main header used across all the pages of our website -->

     
    <header>
      <?php 
      $banner_text = get_theme_mod( 'herring_banner_text' ); 
      if ( ! empty( $banner_text ) ) : 
      ?>
      <div class="banner">
        <p><?php echo wp_kses_post( $banner_text ); ?></p>
      </div>
      <?php endif; ?>

      <div class="top-page-container mb-0">
        

        <a href="https://www.instagram.com/auc.the.herring/" target="_blank" style="display: flex; width: 100%; height: 100%; align-items: center; justify-content: flex-start; box-sizing: border-box;">
          <svg xmlns="http://w3.org" fill="currentColor" class="instagram" viewBox="0 0 16 16" style="width: auto; height: 25px; max-height: 25px;">
            <path d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.9 3.9 0 0 0-1.417.923A3.9 3.9 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.9 3.9 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.9 3.9 0 0 0-.923-1.417A3.9 3.9 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599s.453.546.598.92c.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.5 2.5 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.5 2.5 0 0 1-.92-.598 2.5 2.5 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233s.008-2.388.046-3.231c.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92s.546-.453.92-.598c.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92m-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217m0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334"/>
          </svg>
        </a>
        
        
        <h4 class="date"><span id="current-date"></span></h4>

        <script>
          const dateElement = document.getElementById('current-date');
          const today = new Date();
          const options = { year: 'numeric', month: 'long', day: 'numeric' };
          dateElement.textContent = today.toLocaleDateString('en-US', options);
        </script>
        <div class="actions">
          <a href="#footer" class="newsletterButton">Newsletter</a>
          <a href="https://revolut.me/federieq6i" target="_blank" class="my-button">Donate</a>
        </div>
      </div>
     
      <a href="<?php echo get_option("siteurl"); ?>"><img src="<?php echo get_template_directory_uri(); ?>/logo.png" style="max-width: 40%; height: auto; display: block; margin: auto;">
       <h2 class="subheading">Independent Student Newspaper of Amsterdam University College</h2></a>

      <nav class="navbar navbar-expand-lg navbar-light bg-light">
          
        
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

      <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
        <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
        
       <!-- Culture Dropdown -->
       <li class="nav-item dropdown px-3">
          <a class="nav-link dropdown-toggle" href="<?php echo herring_get_cat_url('culture'); ?>" id="cultureDropdown" aria-haspopup="true" aria-expanded="false">
            Culture
          </a>
          <div class="dropdown-menu" aria-labelledby="cultureDropdown">
            <a class="dropdown-item" href="<?php echo herring_get_cat_url('inside-the-bubble-culture'); ?>">Inside the Bubble</a>
            <a class="dropdown-item" href="<?php echo herring_get_cat_url('outside-the-bubble-culture'); ?>">Outside the Bubble</a>
          </div>
        </li>

        <!-- Politics Dropdown -->
        <li class="nav-item dropdown px-3">
          <a class="nav-link dropdown-toggle" href="<?php echo herring_get_cat_url('politics'); ?>" id="politicsDropdown" aria-haspopup="true" aria-expanded="false">
            Politics
          </a>
          <div class="dropdown-menu" aria-labelledby="politicsDropdown">
            <a class="dropdown-item" href="<?php echo herring_get_cat_url('inside-the-bubble-politics'); ?>">Inside the Bubble</a>
            <a class="dropdown-item" href="<?php echo herring_get_cat_url('outside-the-bubble-politics'); ?>">Outside the Bubble</a>
          </div>
        </li>

        <!-- Standard Categories -->
        <li class="nav-item px-3">
          <a class="nav-link" href="<?php echo herring_get_cat_url('informative'); ?>">Informative</a>
        </li>
        <li class="nav-item px-3">
          <a class="nav-link" href="<?php echo herring_get_cat_url('investigative'); ?>">Investigative</a>
        </li>
        <li class="nav-item px-3">
          <a class="nav-link" href="<?php echo herring_get_cat_url('opinion'); ?>">Opinion</a>
        </li>

        <!-- About Us Dropdown -->
        <li class="nav-item dropdown px-3">
          <a class="nav-link dropdown-toggle" href="#" id="aboutDropdown" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            About Us
          </a>
          <div class="dropdown-menu" aria-labelledby="aboutDropdown">
            <a class="dropdown-item" href="<?php echo home_url('/who-we-are'); ?>">Who We Are</a>
            <a class="dropdown-item" href="<?php echo home_url('/our-staff'); ?>">Our Staff</a>
            <a class="dropdown-item" href="<?php echo home_url('/conduct-and-ethics'); ?>">Conduct and Ethics</a>
            <a class="dropdown-item" href="<?php echo home_url('/commenting-guidelines'); ?>">Commenting Guidelines</a>
          </div>
        </li>

      </ul>
    </div>
  </nav>
</header>